"""
load_silver.py
--------------
Ingestion des fichiers ERP vers silver_raw.* (tables physiques).

- Supporte Excel (.xlsx) et CSV
- Applique une normalisation légère (types/dates)
- Garantit l'idempotence via etl.batch_run (checksum fichier)

Entrées:
- --dataset : salarie | demande_avance | paiement
- --as-of   : date logique du flux (ex: 2024-08-25)
- --file    : chemin du fichier

Sortie:
- Upsert dans silver_raw.<dataset>
- Synchronisation "snapshot" : suppression des lignes absentes du fichier (gestion suppressions)
- 1 ligne dans etl.batch_run (SUCCESS/FAILED)

Ce script suppose que le fichier fourni est un SNAPSHOT complet du dataset à la date donnée.
Si l'ERP envoie des fichiers incrémentaux (delta), il ne faut PAS activer la suppression.

Refactorisation:
- Configuration externalisée dans config/datasets.yml
- Logging structuré pour meilleure traçabilité
- Gestion d'erreurs améliorée avec messages détaillés
"""
import argparse
import os
import logging

import pandas as pd
from psycopg2.extras import execute_values

from scripts.common import (
    get_conn,
    sha256_file,
    register_batch,
    finish_batch,
    upsert_table,
    load_datasets_config,
)

# ==============================================================================
# CONFIGURATION DU LOGGER
# ==============================================================================
logger = logging.getLogger(__name__)


# ==============================================================================
# FONCTIONS DE TRAITEMENT DES FICHIERS
# ==============================================================================

def read_file(path: str) -> pd.DataFrame:
    """
    Lit un fichier CSV ou Excel et retourne un DataFrame pandas.
    
    Formats supportés :
    - .xlsx, .xls : Excel (1ère feuille)
    - .csv : CSV (séparateur auto-détecté)
    
    Args:
        path: Chemin vers le fichier source
        
    Returns:
        DataFrame pandas
        
    Raises:
        ValueError: si l'extension de fichier n'est pas supportée
        
    Exemple:
        >>> df = read_file("data/salaries.xlsx")
    """
    ext = os.path.splitext(path.lower())[1]
    
    logger.info(f"Lecture du fichier: {path} (extension: {ext})")
    
    # Lecture selon l'extension
    if ext in [".xlsx", ".xls"]:
        df = pd.read_excel(path)  # 1ère feuille par défaut
    elif ext == ".csv":
        df = pd.read_csv(path)
    else:
        raise ValueError(f"Unsupported file extension: {ext}. Use .csv, .xlsx, or .xls")
    
    logger.info(f"Fichier lu: {len(df)} lignes, {len(df.columns)} colonnes")
    return df


def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalise un DataFrame pour l'ingestion en base de données.
    
    Traitements appliqués :
    - Suppression des espaces dans les noms de colonnes
    - Remplacement des NaN par None (compatible PostgreSQL)
    
    Args:
        df: DataFrame à normaliser
        
    Returns:
        DataFrame normalisé (modification in-place)
    """
    logger.debug("Normalisation du DataFrame")
    
    # Nettoyage des noms de colonnes (suppression des espaces)
    df.columns = [c.strip() for c in df.columns]
    
    # Remplacement NaN par None (pour compatibilité PostgreSQL)
    df = df.where(pd.notnull(df), None)
    
    return df


def sync_deletions_snapshot(conn, table: str, pk: str, pk_values: list[str]) -> int:
    """
    Gère les suppressions en mode SNAPSHOT.
    
    Principe :
    - Le fichier source contient l'état complet du dataset à la date as_of
    - Toute ligne absente du fichier doit être supprimée de la table
    - Si le fichier est vide, toutes les lignes sont supprimées
    
    Implémentation :
    - Crée une table temporaire avec les clés du fichier
    - Supprime de la table cible toutes les lignes absentes de la table temp
    
    Args:
        conn: Connexion PostgreSQL
        table: Nom de la table cible (ex: "silver_raw.salarie")
        pk: Nom de la colonne clé primaire
        pk_values: Liste des valeurs de clés primaires présentes dans le fichier
        
    Returns:
        Nombre de lignes supprimées
        
    Note:
        Utilise une table temporaire (ON COMMIT DROP) pour performance
    """
    with conn.cursor() as cur:
        # CAS 1: Fichier vide → suppression totale (snapshot vide)
        if not pk_values:
            logger.warning(f"Fichier vide → suppression totale de {table}")
            cur.execute(f"delete from {table};")
            return cur.rowcount

        # CAS 2: Fichier non vide → suppression sélective
        # Création d'une table temporaire pour les clés du fichier
        cur.execute("create temporary table tmp_keys(pk text) on commit drop;")

        # Insertion des clés dans la table temporaire (par batch de 1000)
        values = [(v,) for v in pk_values]
        execute_values(cur, "insert into tmp_keys(pk) values %s", values, page_size=1000)

        # Suppression des lignes absentes du snapshot
        cur.execute(
            f"""
            delete from {table} t
            where not exists (
              select 1 from tmp_keys k where k.pk = t.{pk}
            );
            """
        )
        deleted_count = cur.rowcount
        
        logger.info(f"Snapshot sync: {deleted_count} lignes supprimées de {table}")
        return deleted_count


# ==============================================================================
# FONCTION PRINCIPALE
# ==============================================================================

def main():
    """
    Point d'entrée du script.
    
    Processus :
    1. Parse les arguments CLI
    2. Charge la configuration du dataset depuis YAML
    3. Calcule le checksum du fichier (idempotence)
    4. Enregistre le batch dans etl.batch_run
    5. Lit et normalise le fichier
    6. Upsert dans silver_raw.*
    7. Gère les suppressions (mode snapshot)
    8. Clôture le batch (SUCCESS ou FAILED)
    
    Arguments CLI:
        --dataset: Nom du dataset (salarie, demande_avance, paiement)
        --as-of: Date logique du flux (YYYY-MM-DD)
        --file: Chemin vers le fichier source
        --source: Nom de la source (défaut: "erp")
        --snapshot: Mode snapshot activé par défaut (supprime les lignes absentes)
    """
    # ===== 1. PARSING DES ARGUMENTS =====
    ap = argparse.ArgumentParser(
        description="Load ERP files into silver_raw tables with idempotence + snapshot deletions."
    )
    ap.add_argument(
        "--dataset",
        required=True,
        help="Dataset à charger: salarie | demande_avance | paiement (défini dans config/datasets.yml)"
    )
    ap.add_argument(
        "--as-of",
        required=True,
        help="Date logique du flux (YYYY-MM-DD), ex: 2024-08-25"
    )
    ap.add_argument(
        "--file",
        required=True,
        help="Chemin vers le fichier source (.xlsx/.csv)"
    )
    ap.add_argument(
        "--source",
        default="erp",
        help="Nom de la source (défaut: erp)"
    )
    ap.add_argument(
        "--snapshot",
        action="store_true",
        default=True,
        help="Mode snapshot (par défaut activé) : supprime les lignes absentes du fichier."
    )
    args = ap.parse_args()

    logger.info(f"Démarrage de l'ingestion: dataset={args.dataset}, as_of={args.as_of}, file={args.file}")

    # ===== 2. CHARGEMENT DE LA CONFIGURATION =====
    # On charge la config depuis config/datasets.yml au lieu du dictionnaire en dur
    try:
        datasets_config = load_datasets_config()
    except FileNotFoundError as e:
        logger.error(f"Fichier de configuration introuvable: {e}")
        raise
    
    # Vérification que le dataset existe dans la config
    if args.dataset not in datasets_config:
        available = ", ".join(datasets_config.keys())
        raise ValueError(
            f"Dataset '{args.dataset}' non trouvé dans la configuration. "
            f"Datasets disponibles: {available}"
        )
    
    meta = datasets_config[args.dataset]
    logger.info(f"Configuration chargée: table={meta['table']}, pk={meta['pk']}, cols={len(meta['cols'])}")

    # ===== 3. CALCUL DU CHECKSUM (IDEMPOTENCE) =====
    # Hash SHA256 du fichier pour détecter les rejeux
    try:
        checksum = sha256_file(args.file)
        logger.info(f"Checksum du fichier calculé: {checksum[:16]}...")
    except Exception as e:
        logger.error(f"Erreur lors du calcul du checksum: {e}")
        raise

    # ===== 4. CONNEXION À LA BASE DE DONNÉES =====
    conn = get_conn()
    
    try:
        # ===== 5. ENREGISTREMENT DU BATCH (IDEMPOTENCE) =====
        # Vérifie si ce fichier a déjà été traité
        batch_id = register_batch(conn, args.dataset, args.as_of, args.source, checksum)
        
        if batch_id == -1:
            # Fichier déjà traité → on skip (idempotence)
            print("SKIP: flux déjà traité (idempotent).")
            logger.info("Traitement skippé (idempotent)")
            return

        # ===== 6. LECTURE DU FICHIER =====
        try:
            df = read_file(args.file)
            df = normalize_dataframe(df)
        except Exception as e:
            logger.error(f"Erreur lors de la lecture du fichier: {e}", exc_info=True)
            raise

        # ===== 7. VÉRIFICATION DES COLONNES REQUISES =====
        # Validation que le fichier contient toutes les colonnes attendues
        missing = [c for c in meta["cols"] if c not in df.columns]
        if missing:
            error_msg = (
                f"Missing columns in file for dataset '{args.dataset}': {missing}. "
                f"Columns found: {list(df.columns)}"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

        # ===== 8. SÉLECTION ET CONVERSION DES DONNÉES =====
        # Ne garder que les colonnes définies dans la config
        df = df[meta["cols"]].copy()

        # Conversion des colonnes de type date (si présentes)
        for date_col in ["date_reception", "date_paiement"]:
            if date_col in df.columns:
                logger.debug(f"Conversion de la colonne date: {date_col}")
                df[date_col] = pd.to_datetime(df[date_col], errors="coerce").dt.date

        # Nettoyage de la clé primaire (important pour éviter les doublons)
        pk_col = meta["pk"]
        df[pk_col] = df[pk_col].astype(str).str.strip()

        # Conversion en liste de dictionnaires pour l'upsert
        rows = df.to_dict(orient="records")
        logger.info(f"{len(rows)} lignes prêtes pour l'upsert")

        # ===== 9. UPSERT DANS SILVER_RAW =====
        # Insertion ou mise à jour des données
        upsert_table(conn, meta["table"], meta["pk"], rows, meta["cols"])

        # ===== 10. GESTION DES SUPPRESSIONS (MODE SNAPSHOT) =====
        # Supprime les lignes absentes du fichier (si mode snapshot activé)
        deleted = 0
        if args.snapshot:
            pk_values = df[pk_col].dropna().astype(str).tolist()
            deleted = sync_deletions_snapshot(conn, meta["table"], meta["pk"], pk_values)

        # ===== 11. COMMIT DE LA TRANSACTION =====
        conn.commit()

        # ===== 12. CLÔTURE DU BATCH (SUCCESS) =====
        msg = f"Ingestion {args.dataset} OK ({len(rows)} rows)"
        if args.snapshot:
            msg += f" + snapshot deletions ({deleted} deleted)"
        
        finish_batch(conn, batch_id, "SUCCESS", msg)

        logger.info(f"✓ Traitement terminé avec succès: {len(rows)} rows, {deleted} deleted")
        print(f"OK: batch_id={batch_id} dataset={args.dataset} as_of={args.as_of} rows={len(rows)} deleted={deleted}")

    except Exception as e:
        # ===== GESTION DES ERREURS =====
        logger.error(f"Erreur lors du traitement: {e}", exc_info=True)
        conn.rollback()
        
        # Clôture du batch en FAILED (si batch_id existe)
        try:
            if "batch_id" in locals() and batch_id > 0:
                finish_batch(conn, batch_id, "FAILED", str(e))
        except Exception as finish_error:
            logger.error(f"Erreur lors de la clôture du batch: {finish_error}")
        
        raise
        
    finally:
        # ===== FERMETURE DE LA CONNEXION =====
        conn.close()
        logger.info("Connexion fermée")


if __name__ == "__main__":
    main()
