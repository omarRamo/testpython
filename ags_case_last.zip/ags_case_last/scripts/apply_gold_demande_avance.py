"""
Gold SCD2 - demande_avance (DEMANDE ONLY)
----------------------------------------
Historisation SCD Type 2 des demandes d'avance.

Règles métier (spec respectée) :
- Une demande est indépendante du paiement
- Source : silver.demande_avance
- record_hash basé uniquement sur les attributs DEMANDE
- Suppression : tombstone (is_deleted = true) si absent du flux

Colonnes Gold :
- ref_demande_avance
- ref_salarie
- montant_demande
- valid_from / valid_to
- is_current / is_deleted
- record_hash
- batch_id

Refactorisation:
- Utilise SCD2Handler de common.py pour éviter la duplication de code
- Logging structuré pour meilleure traçabilité
- Context manager pour gestion automatique des transactions
"""
import argparse
import datetime as dt
import logging

from scripts.common import get_conn, get_latest_batch_id, SCD2Handler

# ==============================================================================
# CONFIGURATION DU LOGGER
# ==============================================================================
logger = logging.getLogger(__name__)


# ==============================================================================
# FONCTIONS DE RÉCUPÉRATION DES DONNÉES
# ==============================================================================

def fetch_silver_demande(conn) -> dict:
    """
    Récupère les demandes d'avance depuis la vue Silver (DBT).
    
    Source : silver.demande_avance (vue DBT sur silver_raw.demande_avance)
    Ne contient QUE les attributs de la demande (pas les paiements).
    
    Args:
        conn: Connexion PostgreSQL
        
    Returns:
        dict[ref_demande_avance] = {ref_demande_avance, ref_salarie, montant_demande}
    """
    logger.info("Récupération des données Silver: silver.demande_avance")
    
    sql = """
      select
        ref_demande_avance,
        ref_salarie,
        montant_demande
      from silver.demande_avance
    """
    
    with conn.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()

    # Construction du dictionnaire indexé par ref_demande_avance
    out = {}
    for rda, ref_salarie, montant_demande in rows:
        out[str(rda)] = {
            "ref_demande_avance": str(rda),
            "ref_salarie": str(ref_salarie),
            "montant_demande": float(montant_demande) if montant_demande is not None else None,
        }
    
    logger.info(f"{len(out)} demandes d'avance récupérées depuis Silver")
    return out


def fetch_gold_current(conn) -> dict:
    """
    Récupère les versions courantes depuis la table Gold.
    
    Source : gold.demande_avance_histo (is_current=true uniquement)
    
    Args:
        conn: Connexion PostgreSQL
        
    Returns:
        dict[ref_demande_avance] = {ref_salarie, montant_demande, record_hash, is_deleted}
    """
    logger.info("Récupération des versions courantes Gold: gold.demande_avance_histo")
    
    sql = """
      select
        ref_demande_avance,
        ref_salarie,
        montant_demande,
        record_hash,
        is_deleted
      from gold.demande_avance_histo
      where is_current = true
    """
    
    with conn.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()

    # Construction du dictionnaire avec les données courantes
    out = {}
    for rda, ref_salarie, montant_demande, record_hash, is_deleted in rows:
        out[str(rda)] = {
            "ref_salarie": ref_salarie,
            "montant_demande": montant_demande,
            "record_hash": record_hash,
            "is_deleted": bool(is_deleted),
        }
    
    logger.info(f"{len(out)} versions courantes récupérées depuis Gold")
    return out


# ==============================================================================
# FONCTION PRINCIPALE
# ==============================================================================

def main():
    """
    Point d'entrée du script.
    
    Processus:
    1. Parse les arguments (--as-of)
    2. Récupère le batch_id correspondant au flux Silver
    3. Applique la logique SCD2 via SCD2Handler
    4. Commit ou rollback selon le résultat
    
    Arguments CLI:
        --as-of: Date logique du flux (YYYY-MM-DD), ex: 2024-08-25
    
    Note:
        Le dataset "demande_avance" est codé en dur car c'est toujours la source.
    """
    # ===== 1. PARSING DES ARGUMENTS =====
    ap = argparse.ArgumentParser(
        description="Apply SCD2 historization for gold.demande_avance_histo (DEMANDE ONLY)"
    )
    ap.add_argument(
        "--as-of",
        required=True,
        help="Date logique du flux (YYYY-MM-DD), ex: 2024-08-25"
    )
    args = ap.parse_args()

    # Conversion de la date
    as_of_date = dt.datetime.strptime(args.as_of, "%Y-%m-%d").date()
    logger.info(f"Démarrage du traitement SCD2 pour demande_avance (as_of={args.as_of})")

    # ===== 2. CONNEXION ET TRANSACTION =====
    conn = get_conn()
    conn.autocommit = False  # Mode transactionnel pour garantir l'atomicité

    try:
        # ===== 3. RÉCUPÉRATION DU BATCH_ID =====
        # On récupère le dernier batch SUCCESS du dataset "demande_avance"
        batch_id = get_latest_batch_id(conn, "demande_avance", args.as_of)
        logger.info(f"Batch source identifié: batch_id={batch_id}")

        # ===== 4. INITIALISATION DU HANDLER SCD2 =====
        # Le handler centralise toute la logique SCD2
        # Colonnes métier hashées : ref_salarie, montant_demande
        handler = SCD2Handler(
            conn=conn,
            table_name="gold.demande_avance_histo",
            pk_col="ref_demande_avance",
            business_cols=["ref_salarie", "montant_demande"],
            fetch_silver_func=fetch_silver_demande,
            fetch_gold_func=fetch_gold_current,
        )

        # ===== 5. APPLICATION DU SCD2 =====
        # Gère automatiquement INSERT / UPDATE / DELETE (tombstone)
        stats = handler.apply_scd2(as_of_date, batch_id)

        # ===== 6. COMMIT DE LA TRANSACTION =====
        conn.commit()
        
        logger.info(
            f"✓ Traitement terminé avec succès: "
            f"{stats['inserted']} inserts, {stats['updated']} updates, {stats['deleted']} deletes"
        )
        print(f"OK gold.demande_avance_histo applied for as_of={args.as_of} (batch_id={batch_id})")

    except Exception as e:
        # ===== GESTION DES ERREURS =====
        logger.error(f"Erreur lors du traitement SCD2: {e}", exc_info=True)
        conn.rollback()
        raise
        
    finally:
        # ===== FERMETURE DE LA CONNEXION =====
        conn.close()
        logger.info("Connexion fermée")


if __name__ == "__main__":
    main()
