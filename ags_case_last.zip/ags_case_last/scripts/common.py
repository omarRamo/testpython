"""
common.py
---------
Fonctions utilitaires partagées par les scripts Python.

Ce module porte 5 responsabilités :
1) Connexion PostgreSQL (via variables d'environnement)
2) Idempotence : calcul du checksum et enregistrement dans etl.batch_run
3) Upsert générique dans les tables silver_raw.*
4) Utilitaires de hashing (MD5, SHA256)
5) Classe générique pour gestion SCD Type 2

Pourquoi etl.batch_run ?
- Garantir la rejouabilité (re-run) sans doublons
- Tracer l'origine technique de chaque chargement (batch_id)
"""
import os
import hashlib
import logging
import datetime as dt
from pathlib import Path
from typing import Optional, Dict, List, Callable

import psycopg2
import yaml
from dotenv import load_dotenv
from psycopg2.extras import execute_values

# ==============================================================================
# CONFIGURATION DU LOGGING
# ==============================================================================
# Configure le logger pour toute l'application
# Format: timestamp - niveau - nom du module - message
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

logger = logging.getLogger(__name__)

# ==============================================================================
# CHEMINS ET VARIABLES D'ENVIRONNEMENT
# ==============================================================================
# Charge .env depuis la racine du projet (ags_case/.env)
PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_PATH = PROJECT_ROOT / ".env"
CONFIG_PATH = PROJECT_ROOT / "config" / "datasets.yml"
load_dotenv(dotenv_path=ENV_PATH)


# ==============================================================================
# UTILITAIRES DE HASHING
# ==============================================================================

def md5_hash(values: list) -> str:
    """
    Calcule un hash MD5 à partir d'une liste de valeurs.
    
    Utilisé pour détecter les changements dans les enregistrements SCD2.
    Les valeurs None sont converties en chaînes vides.
    
    Args:
        values: Liste de valeurs à hasher (str, int, float, date, None)
        
    Returns:
        Hash MD5 en hexadécimal (32 caractères)
        
    Exemple:
        >>> md5_hash(["John", "Doe", 123])
        'a1b2c3d4e5f6...'
    """
    # Concatène toutes les valeurs avec le séparateur ||
    s = "||".join("" if v is None else str(v) for v in values)
    # Calcule le hash MD5 et retourne en hexadécimal
    return hashlib.md5(s.encode("utf-8")).hexdigest()


def sha256_file(path: str) -> str:
    """
    Calcule le hash SHA256 d'un fichier (lecture par chunks pour économiser la RAM).
    
    Utilisé pour l'idempotence : si le même fichier est retraité,
    on détecte qu'il a déjà été ingéré.
    
    Args:
        path: Chemin vers le fichier
        
    Returns:
        Hash SHA256 en hexadécimal (64 caractères)
    """
    h = hashlib.sha256()
    # Lecture par blocs de 1Mo pour gérer les gros fichiers
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


# ==============================================================================
# GESTION DE LA CONNEXION POSTGRESQL
# ==============================================================================

def get_conn():
    """
    Crée une connexion PostgreSQL à partir des variables d'environnement.
    
    Variables attendues dans .env :
    - PGHOST : hôte PostgreSQL
    - PGPORT : port (défaut 5432)
    - PGDATABASE : nom de la base de données
    - PGUSER : utilisateur
    - PGPASSWORD : mot de passe
    
    Returns:
        psycopg2.connection
        
    Raises:
        RuntimeError: si une variable d'environnement est manquante
    """
    host = os.getenv("PGHOST")
    port = os.getenv("PGPORT")
    dbname = os.getenv("PGDATABASE")
    user = os.getenv("PGUSER")
    password = os.getenv("PGPASSWORD")

    # Vérification explicite des variables manquantes (utile pour debug)
    missing = [k for k, v in {
        "PGHOST": host,
        "PGPORT": port,
        "PGDATABASE": dbname,
        "PGUSER": user,
        "PGPASSWORD": password,
    }.items() if not v]
    
    if missing:
        raise RuntimeError(f"Missing env vars: {missing}. Check {ENV_PATH}")

    return psycopg2.connect(
        host=host,
        port=int(port),
        dbname=dbname,
        user=user,
        password=password,
    )



# ==============================================================================
# IDEMPOTENCE : GESTION DES BATCH RUNS
# ==============================================================================
# Système de traçabilité et idempotence basé sur la table etl.batch_run
# - Chaque traitement crée un batch avec (dataset, as_of_date, checksum)
# - Si le même fichier (même checksum) est retraité → SKIP automatique
# - Permet de rejouer les traitements en toute sécurité

def register_batch(conn, dataset: str, as_of_date: str, source_name: str, checksum: str) -> int:
    """
    Enregistre un nouveau batch dans etl.batch_run ou retourne -1 si déjà traité.
    
    Principe d'idempotence :
    - Si (dataset, as_of_date, checksum) existe déjà en SUCCESS/SKIPPED → retourne -1
    - Sinon crée un nouveau batch en statut STARTED
    
    Args:
        conn: Connexion PostgreSQL
        dataset: Nom du dataset (salarie, paiement, demande_avance)
        as_of_date: Date logique du flux (YYYY-MM-DD)
        source_name: Nom de la source (ex: "erp")
        checksum: Hash du fichier source (SHA256)
        
    Returns:
        batch_id (entier positif) si nouveau batch créé
        -1 si batch déjà traité (idempotence)
    """
    with conn.cursor() as cur:
        # Vérifier si ce batch existe déjà
        cur.execute(
            """
            select batch_id, status
            from etl.batch_run
            where dataset=%s and as_of_date=%s and source_checksum=%s
            """,
            (dataset, as_of_date, checksum),
        )
        row = cur.fetchone()
        
        if row:
            batch_id, status = row
            # Si déjà traité avec succès ou skippé → idempotence
            if status in ("SUCCESS", "SKIPPED"):
                logger.info(f"Batch déjà traité (idempotent): batch_id={batch_id}, status={status}")
                return -1

        # Créer un nouveau batch en statut STARTED
        cur.execute(
            """
            insert into etl.batch_run(dataset, as_of_date, source_name, source_checksum, status)
            values (%s, %s, %s, %s, 'STARTED')
            returning batch_id
            """,
            (dataset, as_of_date, source_name, checksum),
        )
        batch_id = cur.fetchone()[0]
        logger.info(f"Nouveau batch créé: batch_id={batch_id}, dataset={dataset}, as_of={as_of_date}")

    conn.commit()
    return batch_id


def finish_batch(conn, batch_id: int, status: str, message: str = ""):
    """
    Clôture un batch avec un statut final (SUCCESS ou FAILED).
    
    Met à jour finished_at, status et message dans etl.batch_run.
    
    Args:
        conn: Connexion PostgreSQL
        batch_id: ID du batch à clôturer
        status: 'SUCCESS' ou 'FAILED'
        message: Message descriptif (succès ou erreur)
    """
    with conn.cursor() as cur:
        cur.execute(
            """
            update etl.batch_run
            set finished_at=now(), status=%s, message=%s
            where batch_id=%s
            """,
            (status, message, batch_id),
        )
    conn.commit()
    logger.info(f"Batch clôturé: batch_id={batch_id}, status={status}")


def get_latest_batch_id(conn, dataset: str, as_of_date: str) -> int:
    """
    Récupère le dernier batch SUCCESS pour un (dataset, as_of_date).
    
    Utilisé par les scripts Gold pour savoir quel flux Silver utiliser.
    
    Args:
        conn: Connexion PostgreSQL
        dataset: Nom du dataset
        as_of_date: Date logique (YYYY-MM-DD)
        
    Returns:
        batch_id (entier)
        
    Raises:
        RuntimeError: si aucun batch SUCCESS trouvé
    """
    with conn.cursor() as cur:
        cur.execute(
            """
            select batch_id
            from etl.batch_run
            where dataset = %s
              and as_of_date = %s
              and status = 'SUCCESS'
            order by batch_id desc
            limit 1
            """,
            (dataset, as_of_date),
        )
        row = cur.fetchone()
        
        if not row:
            raise RuntimeError(
                f"No SUCCESS batch found in etl.batch_run for dataset={dataset} as_of_date={as_of_date}"
            )
        
        return int(row[0])


# ==============================================================================
# UPSERT DANS SILVER_RAW
# ==============================================================================
# Permet d'insérer ou mettre à jour les données dans les tables silver_raw
# en mode "upsert" (INSERT ... ON CONFLICT DO UPDATE)

def upsert_table(conn, table: str, pk_col: str, rows: list[dict], cols: list[str]):
    """
    Effectue un upsert (INSERT ... ON CONFLICT UPDATE) dans une table.
    
    Si la clé primaire existe déjà, les colonnes sont mises à jour.
    Cela permet de gérer les corrections ERP sur les flux suivants.
    
    Args:
        conn: Connexion PostgreSQL
        table: Nom de la table cible (ex: "silver_raw.salarie")
        pk_col: Nom de la colonne clé primaire
        rows: Liste de dictionnaires (1 dict = 1 ligne)
        cols: Liste des colonnes à insérer/mettre à jour
        
    Exemple:
        >>> upsert_table(conn, "silver_raw.salarie", "ref_salarie",
        ...              [{"ref_salarie": "S1", "nom": "Dupont"}],
        ...              ["ref_salarie", "nom"])
    """
    if not rows:
        logger.warning(f"Aucune ligne à upserter dans {table}")
        return

    # Préparer les valeurs à insérer
    values = [[r.get(c) for c in cols] for r in rows]
    col_list = ", ".join(cols)
    
    # Construire la clause SET pour l'UPDATE (exclut la PK)
    set_clause = ", ".join([f"{c}=excluded.{c}" for c in cols if c != pk_col])

    # Requête upsert
    sql = f"""
        insert into {table} ({col_list})
        values %s
        on conflict ({pk_col})
        do update set {set_clause}
    """
    
    with conn.cursor() as cur:
        execute_values(cur, sql, values)
    
    conn.commit()
    logger.info(f"Upsert effectué: {len(rows)} lignes dans {table}")


# ==============================================================================
# CHARGEMENT DE LA CONFIGURATION
# ==============================================================================

def load_datasets_config() -> Dict:
    """
    Charge la configuration des datasets depuis config/datasets.yml.
    
    Permet d'externaliser la configuration et d'ajouter de nouveaux datasets
    sans modifier le code Python.
    
    Returns:
        Dictionnaire avec la structure des datasets
        
    Raises:
        FileNotFoundError: si le fichier de config n'existe pas
    """
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"Configuration file not found: {CONFIG_PATH}")
    
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    
    logger.info(f"Configuration chargée: {len(config.get('datasets', {}))} datasets disponibles")
    return config.get("datasets", {})


# ==============================================================================
# CLASSE GÉNÉRIQUE SCD TYPE 2
# ==============================================================================
# Centralise toute la logique d'historisation SCD2 pour éviter la duplication
# de code entre apply_gold_salarie.py, apply_gold_paiement.py, etc.

class SCD2Handler:
    """
    Gestionnaire générique pour l'historisation SCD Type 2.
    
    Principe SCD2 :
    - 1 version "courante" par entité (is_current=true)
    - Période de validité (valid_from/valid_to)
    - Détection des changements via record_hash
    - Gestion des suppressions avec tombstones (is_deleted=true)
    
    Utilisations :
        >>> handler = SCD2Handler(
        ...     conn=conn,
        ...     table_name="gold.salarie_histo",
        ...     pk_col="ref_salarie",
        ...     business_cols=["nni", "nom", "prenom"],
        ...     fetch_silver_func=fetch_silver_salarie,
        ...     fetch_gold_func=fetch_gold_current
        ... )
        >>> handler.apply_scd2(as_of_date, batch_id)
    """
    
    def __init__(
        self,
        conn,
        table_name: str,
        pk_col: str,
        business_cols: List[str],
        fetch_silver_func: Callable,
        fetch_gold_func: Callable,
        additional_cols: Optional[List[str]] = None
    ):
        """
        Initialise le gestionnaire SCD2.
        
        Args:
            conn: Connexion PostgreSQL
            table_name: Nom de la table Gold (ex: "gold.salarie_histo")
            pk_col: Nom de la clé primaire (ex: "ref_salarie")
            business_cols: Colonnes métier à hasher (ex: ["nni", "nom", "prenom"])
            fetch_silver_func: Fonction pour récupérer les données Silver
            fetch_gold_func: Fonction pour récupérer les versions courantes Gold
            additional_cols: Colonnes supplémentaires à insérer (optionnel)
        """
        self.conn = conn
        self.table_name = table_name
        self.pk_col = pk_col
        self.business_cols = business_cols
        self.fetch_silver_func = fetch_silver_func
        self.fetch_gold_func = fetch_gold_func
        self.additional_cols = additional_cols or []
        
        logger.info(f"SCD2Handler initialisé pour {table_name}")
    
    def _compute_hash(self, row: dict, is_deleted: bool) -> str:
        """
        Calcule le hash d'un enregistrement (colonnes métier + is_deleted).
        
        Permet de détecter si l'enregistrement a changé.
        """
        values = [row.get(col) for col in self.business_cols] + [is_deleted]
        return md5_hash(values)
    
    def _close_current(self, pk_value: str, as_of_date: dt.date):
        """
        Ferme la version courante d'un enregistrement.
        
        Met à jour valid_to et is_current=false.
        """
        with self.conn.cursor() as cur:
            cur.execute(
                f"""
                update {self.table_name}
                set valid_to = %s,
                    is_current = false
                where {self.pk_col} = %s
                  and is_current = true
                """,
                (as_of_date, pk_value),
            )
        logger.debug(f"Version courante fermée: {self.pk_col}={pk_value}")
    
    def _insert_version(self, row: dict, as_of_date: dt.date, batch_id: int, is_deleted: bool):
        """
        Insère une nouvelle version dans la table d'historique.
        
        Args:
            row: Dictionnaire contenant les données de l'enregistrement
            as_of_date: Date de début de validité
            batch_id: ID du batch qui a produit cette version
            is_deleted: True si c'est un tombstone (suppression logique)
        """
        # Calculer le hash de l'enregistrement
        record_hash = self._compute_hash(row, is_deleted)
        
        # Construire la liste des colonnes et valeurs
        cols = [self.pk_col] + self.business_cols + self.additional_cols
        cols += ["valid_from", "valid_to", "is_current", "is_deleted", "record_hash", "batch_id"]
        
        placeholders = ", ".join(["%s"] * len(cols))
        col_names = ", ".join(cols)
        
        # Préparer les valeurs
        values = [row[self.pk_col]]
        values += [row.get(col) for col in self.business_cols]
        values += [row.get(col) for col in self.additional_cols]
        values += [as_of_date, dt.date(9999, 12, 31), True, is_deleted, record_hash, batch_id]
        
        # Insertion
        with self.conn.cursor() as cur:
            cur.execute(
                f"insert into {self.table_name} ({col_names}) values ({placeholders})",
                values,
            )
        
        logger.debug(f"Nouvelle version insérée: {self.pk_col}={row[self.pk_col]}, is_deleted={is_deleted}")
    
    def apply_scd2(self, as_of_date: dt.date, batch_id: int) -> dict:
        """
        Applique la logique SCD2 complète.
        
        Processus :
        1. Récupère les données Silver (flux entrant)
        2. Récupère les versions courantes Gold (état actuel)
        3. Pour chaque ligne Silver :
           - Si nouvelle → INSERT
           - Si modifiée → CLOSE + INSERT
           - Si réactivée (était deleted) → CLOSE + INSERT
        4. Pour chaque ligne Gold absente de Silver → suppression logique (tombstone)
        
        Args:
            as_of_date: Date logique du traitement
            batch_id: ID du batch associé
            
        Returns:
            Statistiques du traitement (inserted, updated, deleted)
        """
        logger.info(f"Début du traitement SCD2 pour {self.table_name} (as_of={as_of_date}, batch_id={batch_id})")
        
        # 1. Récupération des données sources
        silver = self.fetch_silver_func(self.conn)
        gold_current = self.fetch_gold_func(self.conn)
        
        silver_keys = set(silver.keys())
        gold_keys = set(gold_current.keys())
        
        stats = {"inserted": 0, "updated": 0, "deleted": 0}
        
        # 2. Traitement des INSERTS et UPDATES (présents dans Silver)
        for pk_value in silver_keys:
            row = silver[pk_value]
            new_hash = self._compute_hash(row, is_deleted=False)
            
            if pk_value not in gold_current:
                # CAS 1: Nouvelle entité → INSERT
                self._insert_version(row, as_of_date, batch_id, is_deleted=False)
                stats["inserted"] += 1
                
            else:
                # CAS 2: Entité existante
                gold_row = gold_current[pk_value]
                
                # Vérifier si modification ou réactivation
                if gold_row["record_hash"] != new_hash or gold_row["is_deleted"] is True:
                    # Changement détecté → CLOSE ancienne version + INSERT nouvelle
                    self._close_current(pk_value, as_of_date)
                    self._insert_version(row, as_of_date, batch_id, is_deleted=False)
                    stats["updated"] += 1
        
        # 3. Traitement des DELETES (absents du flux Silver)
        deleted_keys = gold_keys - silver_keys
        for pk_value in deleted_keys:
            gold_row = gold_current[pk_value]
            
            # Ne traiter que si pas déjà marqué comme deleted
            if gold_row["is_deleted"] is False:
                # Fermer la version courante
                self._close_current(pk_value, as_of_date)
                
                # Créer un tombstone (version is_deleted=true)
                # On réutilise les dernières valeurs connues
                tomb = {self.pk_col: pk_value}
                for col in self.business_cols + self.additional_cols:
                    tomb[col] = gold_row.get(col)
                
                self._insert_version(tomb, as_of_date, batch_id, is_deleted=True)
                stats["deleted"] += 1
        
        logger.info(f"SCD2 terminé: {stats['inserted']} inserts, {stats['updated']} updates, {stats['deleted']} deletes")
        return stats


# Idempotence:
# - si (dataset, as_of_date, checksum) existe déjà en SUCCESS => SKIP
# - sinon => on crée un batch STARTED puis on le clôture en SUCCESS/FAILED

def register_batch(conn, dataset: str, as_of_date: str, source_name: str, checksum: str) -> int:

