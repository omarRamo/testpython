"""
Gold SCD2 - paiement
-------------------
Alimente la table gold.paiement_histo en SCD Type 2.

Principe:
- 1 version "courante" (is_current=true) + période de validité (valid_from/valid_to)
- Détection des changements métier via record_hash
- Si changement: close version courante + insert nouvelle version
- Si suppression (absent du flux): close + insert version is_deleted=true

Traçabilité:
- batch_id = lien vers etl.batch_run (quel flux a produit la version)

Refactorisation:
- Utilise SCD2Handler de common.py pour éviter la duplication de code
- Logging structuré pour meilleure traçabilité
- Context manager pour gestion automatique des transactions
"""
import argparse
import datetime as dt
import logging

from scripts.common import get_conn, get_latest_batch_id, SCD2Handler

# ==============================================================================
# CONFIGURATION DU LOGGER
# ==============================================================================
logger = logging.getLogger(__name__)


# ==============================================================================
# FONCTIONS DE RÉCUPÉRATION DES DONNÉES
# ==============================================================================

def fetch_silver_paiement(conn) -> dict:
    """
    Récupère les données paiements depuis la vue Silver (DBT).
    
    Source : silver.paiement (vue DBT sur silver_raw.paiement)
    
    Args:
        conn: Connexion PostgreSQL
        
    Returns:
        dict[ref_paiement] = {ref_paiement, ref_salarie, montant_paye, 
                              rib_salarie, date_paiement, ref_demande_avance}
    """
    logger.info("Récupération des données Silver: silver.paiement")
    
    with conn.cursor() as cur:
        cur.execute(
            """
            select ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance
            from silver.paiement
            """
        )
        rows = cur.fetchall()

    # Construction du dictionnaire indexé par ref_paiement
    out = {}
    for ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance in rows:
        out[str(ref_paiement)] = {
            "ref_paiement": str(ref_paiement),
            "ref_salarie": str(ref_salarie),
            "montant_paye": float(montant_paye) if montant_paye is not None else None,
            "rib_salarie": str(rib_salarie),
            "date_paiement": date_paiement,  # type date
            "ref_demande_avance": str(ref_demande_avance),
        }
    
    logger.info(f"{len(out)} paiements récupérés depuis Silver")
    return out


def fetch_gold_current(conn) -> dict:
    """
    Récupère les versions courantes depuis la table Gold.
    
    Source : gold.paiement_histo (is_current=true uniquement)
    
    Args:
        conn: Connexion PostgreSQL
        
    Returns:
        dict[ref_paiement] = {ref_salarie, montant_paye, rib_salarie, 
                              date_paiement, ref_demande_avance, record_hash, is_deleted}
    """
    logger.info("Récupération des versions courantes Gold: gold.paiement_histo")
    
    with conn.cursor() as cur:
        cur.execute(
            """
            select
              ref_paiement,
              ref_salarie,
              montant_paye,
              rib_salarie,
              date_paiement,
              ref_demande_avance,
              record_hash,
              is_deleted
            from gold.paiement_histo
            where is_current = true
            """
        )
        rows = cur.fetchall()

    # Construction du dictionnaire avec les données courantes
    out = {}
    for (ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, 
         ref_demande_avance, record_hash, is_deleted) in rows:
        out[str(ref_paiement)] = {
            "ref_salarie": ref_salarie,
            "montant_paye": montant_paye,
            "rib_salarie": rib_salarie,
            "date_paiement": date_paiement,
            "ref_demande_avance": ref_demande_avance,
            "record_hash": record_hash,
            "is_deleted": bool(is_deleted),
        }
    
    logger.info(f"{len(out)} versions courantes récupérées depuis Gold")
    return out


# ==============================================================================
# FONCTION PRINCIPALE
# ==============================================================================

def main():
    """
    Point d'entrée du script.
    
    Processus:
    1. Parse les arguments (--as-of, --batch-dataset)
    2. Récupère le batch_id correspondant au flux Silver
    3. Applique la logique SCD2 via SCD2Handler
    4. Commit ou rollback selon le résultat
    
    Arguments CLI:
        --as-of: Date logique du flux (YYYY-MM-DD), ex: 2024-08-25
        --batch-dataset: Nom du dataset dans etl.batch_run (défaut: "paiement")
    """
    # ===== 1. PARSING DES ARGUMENTS =====
    ap = argparse.ArgumentParser(
        description="Apply SCD2 historization for gold.paiement_histo from silver.paiement"
    )
    ap.add_argument(
        "--as-of",
        required=True,
        help="Date logique du flux (YYYY-MM-DD), ex: 2024-08-25"
    )
    ap.add_argument(
        "--batch-dataset",
        default="paiement",
        help="Nom du dataset dans etl.batch_run (défaut: paiement)"
    )
    args = ap.parse_args()

    # Conversion de la date
    as_of_date = dt.datetime.strptime(args.as_of, "%Y-%m-%d").date()
    logger.info(f"Démarrage du traitement SCD2 pour paiement (as_of={args.as_of})")

    # ===== 2. CONNEXION ET TRANSACTION =====
    conn = get_conn()
    conn.autocommit = False  # Mode transactionnel pour garantir l'atomicité
    
    try:
        # ===== 3. RÉCUPÉRATION DU BATCH_ID =====
        # On récupère le dernier batch SUCCESS du dataset source
        batch_id = get_latest_batch_id(conn, args.batch_dataset, args.as_of)
        logger.info(f"Batch source identifié: batch_id={batch_id}")

        # ===== 4. INITIALISATION DU HANDLER SCD2 =====
        # Le handler centralise toute la logique SCD2
        # Colonnes métier hashées : ref_salarie, montant_paye, rib_salarie, 
        #                           date_paiement, ref_demande_avance
        handler = SCD2Handler(
            conn=conn,
            table_name="gold.paiement_histo",
            pk_col="ref_paiement",
            business_cols=["ref_salarie", "montant_paye", "rib_salarie", 
                          "date_paiement", "ref_demande_avance"],
            fetch_silver_func=fetch_silver_paiement,
            fetch_gold_func=fetch_gold_current,
        )

        # ===== 5. APPLICATION DU SCD2 =====
        # Gère automatiquement INSERT / UPDATE / DELETE (tombstone)
        stats = handler.apply_scd2(as_of_date, batch_id)

        # ===== 6. COMMIT DE LA TRANSACTION =====
        conn.commit()
        
        logger.info(
            f"✓ Traitement terminé avec succès: "
            f"{stats['inserted']} inserts, {stats['updated']} updates, {stats['deleted']} deletes"
        )
        print(f"OK gold.paiement_histo applied for as_of={args.as_of} (batch_id={batch_id})")

    except Exception as e:
        # ===== GESTION DES ERREURS =====
        logger.error(f"Erreur lors du traitement SCD2: {e}", exc_info=True)
        conn.rollback()
        raise
        
    finally:
        # ===== FERMETURE DE LA CONNEXION =====
        conn.close()
        logger.info("Connexion fermée")


if __name__ == "__main__":
    main()
