# 🔄 Guide de migration - Code refactorisé

## Installation des nouvelles dépendances

```powershell
# Installer les nouvelles dépendances
pip install -r requirements.txt

# Vérifier l'installation de PyYAML
python -c "import yaml; print('PyYAML OK')"
```

---

## Utilisation inchangée des scripts

### ✅ Les commandes restent identiques

```powershell
# Ingestion Silver (INCHANGÉ)
python scripts/load_silver.py `
  --dataset salarie `
  --as-of 2024-08-25 `
  --file data/salaries.xlsx

# Historisation Gold (INCHANGÉ)
python scripts/apply_gold_salarie.py --as-of 2024-08-25
python scripts/apply_gold_paiement.py --as-of 2024-08-25
python scripts/apply_gold_demande_avance.py --as-of 2024-08-25
```

---

## 🆕 Nouveautés

### 1. Configuration externalisée

**Fichier** : `config/datasets.yml`

Pour ajouter un nouveau dataset :

```yaml
datasets:
  mon_nouveau_dataset:
    table: silver_raw.mon_dataset
    pk: ref_mon_dataset
    cols:
      - ref_mon_dataset
      - colonne1
      - colonne2
```

**Puis utiliser directement** :
```powershell
python scripts/load_silver.py `
  --dataset mon_nouveau_dataset `
  --as-of 2024-08-25 `
  --file data/fichier.xlsx
```

---

### 2. Logs améliorés

**Avant** :
```
OK: batch_id=123 dataset=salarie as_of=2024-08-25 rows=100 deleted=0
```

**Après** :
```
2026-02-03 14:30:15 - INFO - load_silver - Démarrage de l'ingestion: dataset=salarie, as_of=2024-08-25
2026-02-03 14:30:15 - INFO - load_silver - Configuration chargée: table=silver_raw.salarie, pk=ref_salarie
2026-02-03 14:30:16 - INFO - load_silver - Fichier lu: 100 lignes, 5 colonnes
2026-02-03 14:30:17 - INFO - common - Upsert effectué: 100 lignes dans silver_raw.salarie
2026-02-03 14:30:17 - INFO - load_silver - ✓ Traitement terminé avec succès: 100 rows, 0 deleted
```

---

### 3. Gestion d'erreurs renforcée

**Avant** (pas de détails) :
```python
except Exception:
    conn.rollback()
    raise
```

**Après** (logs détaillés) :
```python
except Exception as e:
    logger.error(f"Erreur lors du traitement: {e}", exc_info=True)
    conn.rollback()
    finish_batch(conn, batch_id, "FAILED", str(e))
    raise
```

**Résultat** : Stack trace complète dans les logs pour debug facile

---

## 🔍 Debugging

### Activer les logs de debug

Modifier temporairement `common.py` :

```python
# Ligne 27 de common.py
logging.basicConfig(
    level=logging.DEBUG,  # ← Changer INFO en DEBUG
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
```

---

## 📝 Checklist de migration

- [ ] Installer les nouvelles dépendances (`pip install -r requirements.txt`)
- [ ] Vérifier que `config/datasets.yml` existe
- [ ] Tester un script d'ingestion Silver
- [ ] Tester un script Gold SCD2
- [ ] Vérifier que les logs s'affichent correctement
- [ ] Valider que les données en base sont identiques (régression)

---

## ❓ FAQ

### Q: Est-ce que je dois changer mes scripts orchestration ?
**R:** Non, les commandes CLI restent identiques.

### Q: Où sont les logs ?
**R:** Affichés dans la console (stdout) au format structuré.

### Q: Comment ajouter un nouveau dataset ?
**R:** Modifier `config/datasets.yml` uniquement, pas de code Python à toucher.

### Q: Les performances ont-elles changé ?
**R:** Non, la logique métier est strictement identique, seule l'organisation du code a changé.

### Q: Puis-je revenir à l'ancienne version ?
**R:** Oui, via git : `git checkout HEAD~1` (mais ce n'est pas recommandé car le nouveau code est meilleur)

---

## 🐛 Signaler un problème

Si vous rencontrez un bug :

1. Activer les logs DEBUG
2. Copier la stack trace complète
3. Vérifier que `config/datasets.yml` est bien formaté (YAML valide)
4. Tester avec l'ancien code pour confirmer la régression
