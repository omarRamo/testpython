"""
scd2_base.py
------------
Classe de base pour gérer l'historisation SCD Type 2 (Slowly Changing Dimension).

Ce module fournit une classe abstraite pour éviter la duplication de code
entre apply_gold_salarie.py, apply_gold_demande_avance.py et apply_gold_paiement.py.

Principe SCD2:
- 1 version "courante" (is_current=true) + période de validité (valid_from/valid_to)
- Détection des changements métier via record_hash
- Si changement: close version courante + insert nouvelle version
- Si suppression (absent du flux): close + insert version is_deleted=true

Traçabilité:
- batch_id = lien vers etl.batch_run (quel flux a produit la version)
"""
import datetime as dt
from abc import ABC, abstractmethod
from typing import Dict, Any, List

from scripts.common import get_conn, get_latest_batch_id, md5_hash, MAX_DATE_SCD2, logger


# ============================================================
# CLASSE ABSTRAITE POUR SCD2
# ============================================================

class SCD2Handler(ABC):
    """
    Classe de base pour gérer l'historisation SCD Type 2.
    
    Les classes enfants doivent définir:
    - entity_name: nom de l'entité (ex: 'salarie', 'paiement')
    - pk_col: nom de la colonne de clé primaire (ex: 'ref_salarie')
    - business_cols: colonnes métier à inclure dans le hash
    - fetch_silver(): méthode pour récupérer les données depuis silver
    - fetch_gold_current(): méthode pour récupérer les versions courantes dans gold
    """
    
    def __init__(self, entity_name: str, pk_col: str, business_cols: List[str]):
        """
        Initialise le gestionnaire SCD2.
        
        Args:
            entity_name: Nom de l'entité (ex: 'salarie', 'demande_avance', 'paiement')
            pk_col: Nom de la colonne de clé primaire
            business_cols: Liste des colonnes métier pour le calcul du hash
        """
        self.entity_name = entity_name
        self.pk_col = pk_col
        self.business_cols = business_cols
        self.table_gold = f"gold.{entity_name}_histo"
    
    @abstractmethod
    def fetch_silver(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les données depuis la couche Silver.
        
        Args:
            conn: Connexion PostgreSQL
            
        Returns:
            Dict avec clé primaire => dictionnaire de données
            
        Note:
            À implémenter dans les classes enfants
        """
        pass
    
    @abstractmethod
    def fetch_gold_current(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les versions courantes (is_current=true) depuis Gold.
        
        Args:
            conn: Connexion PostgreSQL
            
        Returns:
            Dict avec clé primaire => dictionnaire de données (incluant record_hash et is_deleted)
            
        Note:
            À implémenter dans les classes enfants
        """
        pass
    
    @abstractmethod
    def build_insert_values(self, row: Dict[str, Any], as_of_date: dt.date, 
                          batch_id: int, is_deleted: bool) -> tuple:
        """
        Construit le tuple de valeurs pour l'insertion dans Gold.
        
        Args:
            row: Dictionnaire contenant les données de la ligne
            as_of_date: Date logique de validité
            batch_id: ID du batch d'origine
            is_deleted: Indicateur de suppression logique
            
        Returns:
            Tuple de valeurs pour l'INSERT
            
        Note:
            À implémenter dans les classes enfants
        """
        pass
    
    @abstractmethod
    def get_insert_sql(self) -> str:
        """
        Retourne la requête SQL d'insertion dans la table Gold.
        
        Returns:
            Requête SQL INSERT avec placeholders %s
            
        Note:
            À implémenter dans les classes enfants
        """
        pass
    
    def calculate_hash(self, row: Dict[str, Any], is_deleted: bool) -> str:
        """
        Calcule le hash métier d'une ligne (pour détecter les changements).
        
        Args:
            row: Dictionnaire contenant les données
            is_deleted: Indicateur de suppression logique
            
        Returns:
            Hash MD5 en hexadécimal
        """
        # Extraire les valeurs des colonnes métier dans l'ordre défini
        values = [row.get(col) for col in self.business_cols]
        values.append(is_deleted)  # Inclure le statut de suppression dans le hash
        return md5_hash(values)
    
    def close_current(self, conn, pk_value: str, as_of_date: dt.date):
        """
        Clôture la version courante d'un enregistrement (SCD2).
        
        Args:
            conn: Connexion PostgreSQL
            pk_value: Valeur de la clé primaire
            as_of_date: Date de fin de validité
        """
        with conn.cursor() as cur:
            # Met à jour valid_to et is_current pour clôturer la version courante
            cur.execute(
                f"""
                update {self.table_gold}
                set valid_to = %s,
                    is_current = false
                where {self.pk_col} = %s
                  and is_current = true
                """,
                (as_of_date, pk_value),
            )
            logger.debug(f"Closed current version for {self.pk_col}={pk_value}")
    
    def insert_version(self, conn, row: Dict[str, Any], as_of_date: dt.date, 
                      batch_id: int, is_deleted: bool):
        """
        Insère une nouvelle version dans la table Gold (SCD2).
        
        Args:
            conn: Connexion PostgreSQL
            row: Dictionnaire contenant les données
            as_of_date: Date de début de validité
            batch_id: ID du batch d'origine
            is_deleted: Indicateur de suppression logique
        """
        # Construire les valeurs pour l'insert
        values = self.build_insert_values(row, as_of_date, batch_id, is_deleted)
        
        with conn.cursor() as cur:
            # Insérer la nouvelle version
            cur.execute(self.get_insert_sql(), values)
            action = "deleted" if is_deleted else "inserted/updated"
            logger.debug(f"Version {action} for {self.pk_col}={row.get(self.pk_col)}")
    
    def apply_scd2(self, conn, as_of_date: dt.date, batch_id: int):
        """
        Applique la logique SCD2 complète: inserts, updates et suppressions logiques.
        
        Args:
            conn: Connexion PostgreSQL
            as_of_date: Date logique du flux
            batch_id: ID du batch d'origine
            
        Process:
            1. Charger les données Silver (source) et Gold courantes (cible)
            2. Pour chaque ligne dans Silver:
               - Si nouvelle => insert version
               - Si modifiée (hash différent) ou réactivée => close + insert nouvelle version
            3. Pour chaque ligne dans Gold absente de Silver:
               - Si non deleted => close + insert version "tombstone" (is_deleted=true)
        """
        logger.info(f"Starting SCD2 processing for {self.entity_name}, as_of={as_of_date}")
        
        # 1) Charger les données sources (Silver) et cibles (Gold)
        silver = self.fetch_silver(conn)
        gold_current = self.fetch_gold_current(conn)
        
        silver_keys = set(silver.keys())
        gold_keys = set(gold_current.keys())
        
        logger.info(f"Silver records: {len(silver_keys)}, Gold current records: {len(gold_keys)}")
        
        # 2) Traiter les inserts et updates (données présentes dans Silver)
        inserts = 0
        updates = 0
        for pk_value in silver_keys:
            row = silver[pk_value]
            # Calculer le hash de la nouvelle version (is_deleted=False)
            new_hash = self.calculate_hash(row, is_deleted=False)
            
            if pk_value not in gold_current:
                # Nouveau enregistrement => insert version initiale
                self.insert_version(conn, row, as_of_date, batch_id, is_deleted=False)
                inserts += 1
            else:
                # Enregistrement existant => vérifier si modification ou réactivation
                old_hash = gold_current[pk_value]["record_hash"]
                was_deleted = gold_current[pk_value]["is_deleted"]
                
                if old_hash != new_hash or was_deleted:
                    # Hash différent OU réactivation d'un deleted => nouvelle version
                    self.close_current(conn, pk_value, as_of_date)
                    self.insert_version(conn, row, as_of_date, batch_id, is_deleted=False)
                    updates += 1
                # Sinon: aucun changement, on ne fait rien (SCD2)
        
        # 3) Traiter les suppressions logiques (absents de Silver mais présents dans Gold)
        deleted_keys = gold_keys - silver_keys
        deletions = 0
        for pk_value in deleted_keys:
            if not gold_current[pk_value]["is_deleted"]:
                # Enregistrement non encore marqué comme deleted
                # => clôturer la version courante + insérer une version "tombstone"
                self.close_current(conn, pk_value, as_of_date)
                
                # Créer un tombstone avec les dernières valeurs connues
                tomb = {col: gold_current[pk_value].get(col) for col in self.business_cols}
                tomb[self.pk_col] = pk_value  # Ajouter la clé primaire
                
                self.insert_version(conn, tomb, as_of_date, batch_id, is_deleted=True)
                deletions += 1
        
        logger.info(f"SCD2 completed: {inserts} inserts, {updates} updates, {deletions} deletions")
        
        return {
            "inserts": inserts,
            "updates": updates,
            "deletions": deletions
        }
    
    def run(self, as_of: str, batch_dataset: str = None):
        """
        Point d'entrée principal pour exécuter le traitement SCD2.
        
        Args:
            as_of: Date logique du flux (format: YYYY-MM-DD)
            batch_dataset: Nom du dataset dans etl.batch_run (par défaut: entity_name)
        """
        # Convertir la date string en objet date
        as_of_date = dt.datetime.strptime(as_of, "%Y-%m-%d").date()
        
        # Par défaut, le dataset est le nom de l'entité
        if batch_dataset is None:
            batch_dataset = self.entity_name
        
        # Établir la connexion (mode transactionnel)
        conn = get_conn()
        conn.autocommit = False
        
        try:
            # Récupérer le batch_id correspondant au chargement Silver
            batch_id = get_latest_batch_id(conn, batch_dataset, as_of)
            logger.info(f"Processing batch_id={batch_id} for {self.entity_name}")
            
            # Appliquer la logique SCD2
            stats = self.apply_scd2(conn, as_of_date, batch_id)
            
            # Valider la transaction
            conn.commit()
            logger.info(f"OK {self.table_gold} applied for as_of={as_of} - Stats: {stats}")
            print(f"OK {self.table_gold} applied for as_of={as_of} (batch_id={batch_id})")
            
        except Exception as e:
            # En cas d'erreur, rollback de toute la transaction
            logger.error(f"Error during SCD2 processing: {e}", exc_info=True)
            conn.rollback()
            raise
        finally:
            # Fermer proprement la connexion
            conn.close()
