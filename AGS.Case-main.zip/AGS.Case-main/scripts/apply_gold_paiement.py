"""
Gold SCD2 - paiement
-------------------
Alimente la table gold.paiement_histo en SCD Type 2.

Principe:
- 1 version "courante" (is_current=true) + période de validité (valid_from/valid_to)
- Détection des changements métier via record_hash
- Si changement: close version courante + insert nouvelle version
- Si suppression (absent du flux): close + insert version is_deleted=true

Traçabilité:
- batch_id = lien vers etl.batch_run (quel flux a produit la version)
"""
import argparse
import datetime as dt
from typing import Dict, Any

from scripts.scd2_base import SCD2Handler
from scripts.common import md5_hash, MAX_DATE_SCD2


# ============================================================
# CLASSE SPÉCIALISÉE POUR PAIEMENT
# ============================================================

class PaiementSCD2Handler(SCD2Handler):
    """
    Gestionnaire SCD2 spécifique pour l'entité Paiement.
    
    Colonnes métier: ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance
    """
    
    def __init__(self):
        # Initialiser avec les spécificités de l'entité Paiement
        super().__init__(
            entity_name="paiement",
            pk_col="ref_paiement",
            business_cols=["ref_salarie", "montant_paye", "rib_salarie", "date_paiement", "ref_demande_avance"]
        )
    
    def fetch_silver(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les données depuis silver.paiement (vue DBT).
        
        Returns:
            dict[ref_paiement] = {ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance}
            """
        with conn.cursor() as cur:
            cur.execute(
                """
                select ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance
                from silver.paiement
                """
            )
            rows = cur.fetchall()

        # Transformer en dictionnaire indexé par ref_paiement
        out = {}
        for ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance in rows:
            out[str(ref_paiement)] = {
                "ref_paiement": str(ref_paiement),
                "ref_salarie": str(ref_salarie),
                "montant_paye": float(montant_paye) if montant_paye is not None else None,
                "rib_salarie": str(rib_salarie),
                "date_paiement": date_paiement,  # date
                "ref_demande_avance": str(ref_demande_avance),
            }
        return out
    
    def fetch_gold_current(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les versions courantes depuis gold.paiement_histo.
        
        Returns:
            dict[ref_paiement] = {ref_salarie, montant_paye, rib_salarie, date_paiement, ref_demande_avance, record_hash, is_deleted}
            """
        with conn.cursor() as cur:
            cur.execute(
                """
                select
                  ref_paiement,
                  ref_salarie,
                  montant_paye,
                  rib_salarie,
                  date_paiement,
                  ref_demande_avance,
                  record_hash,
                  is_deleted
                from gold.paiement_histo
                where is_current = true
                """
            )
            rows = cur.fetchall()

        # Transformer en dictionnaire indexé par ref_paiement
        out = {}
        for (ref_paiement, ref_salarie, montant_paye, rib_salarie, date_paiement, 
             ref_demande_avance, record_hash, is_deleted) in rows:
            out[str(ref_paiement)] = {
                "ref_paiement": str(ref_paiement),  # Inclure la PK pour tombstone
                "ref_salarie": ref_salarie,
                "montant_paye": montant_paye,
                "rib_salarie": rib_salarie,
                "date_paiement": date_paiement,
                "ref_demande_avance": ref_demande_avance,
                "record_hash": record_hash,
                "is_deleted": bool(is_deleted),
            }
        return out
    
    def build_insert_values(self, row: Dict[str, Any], as_of_date: dt.date, 
                          batch_id: int, is_deleted: bool) -> tuple:
        """
        Construit le tuple de valeurs pour l'INSERT dans gold.paiement_histo.
        """
        # Calculer le hash de la version (inclut is_deleted)
        record_hash = md5_hash([
            row["ref_salarie"],
            row["montant_paye"],
            row["rib_salarie"],
            row["date_paiement"],
            row["ref_demande_avance"],
            is_deleted,
        ])
        
        # Retourner les valeurs dans l'ordre de la requête INSERT
        return (
            row["ref_paiement"],
            row["ref_salarie"],
            row["montant_paye"],
            row["rib_salarie"],
            row["date_paiement"],
            row["ref_demande_avance"],
            as_of_date,           # valid_from
            is_deleted,           # is_deleted
            record_hash,          # record_hash
            batch_id,             # batch_id
        )
    
    def get_insert_sql(self) -> str:
        """
        Retourne la requête SQL d'insertion dans gold.paiement_histo.
        """
        return f"""
            insert into {self.table_gold} (
              ref_paiement,
              ref_salarie,
              montant_paye,
              rib_salarie,
              date_paiement,
              ref_demande_avance,
              valid_from,
              valid_to,
              is_current,
              is_deleted,
              record_hash,
              batch_id
            )
            values (%s,%s,%s,%s,%s,%s, %s, date '{MAX_DATE_SCD2}', true, %s, %s, %s)
        """


# ============================================================
# POINT D'ENTRÉE PRINCIPAL
# ============================================================

def main():
    """
    Point d'entrée pour l'exécution du script en ligne de commande.
    
    Parse les arguments et déclenche le traitement SCD2 pour paiement.
    """
    # Parser les arguments de ligne de commande
    ap = argparse.ArgumentParser(
        description="Apply SCD2 historization for gold.paiement_histo from silver.paiement"
    )
    ap.add_argument(
        "--as-of", 
        required=True, 
        help="Date logique du flux (format: YYYY-MM-DD), ex: 2024-08-25"
    )
    ap.add_argument(
        "--batch-dataset", 
        default="paiement", 
        help="Nom du dataset dans etl.batch_run (default: paiement)"
    )
    args = ap.parse_args()

    # Créer le gestionnaire SCD2 pour paiement
    handler = PaiementSCD2Handler()
    
    # Exécuter le traitement
    handler.run(as_of=args.as_of, batch_dataset=args.batch_dataset)


if __name__ == "__main__":
    main()
