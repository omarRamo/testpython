"""
Gold SCD2 - demande_avance
-------------------
Alimente la table gold.demande_avance_histo en SCD Type 2.

Principe:
- 1 version "courante" (is_current=true) + période de validité (valid_from/valid_to)
- Détection des changements métier via record_hash
- Si changement: close version courante + insert nouvelle version
- Si suppression (absent du flux): close + insert version is_deleted=true

Traçabilité:
- batch_id = lien vers etl.batch_run (quel flux a produit la version)
"""

import argparse
import datetime as dt
from typing import Dict, Any

from scripts.scd2_base import SCD2Handler
from scripts.common import md5_hash, MAX_DATE_SCD2


# ============================================================
# CLASSE SPÉCIALISÉE POUR DEMANDE AVANCE
# ============================================================

class DemandeAvanceSCD2Handler(SCD2Handler):
    """
    Gestionnaire SCD2 spécifique pour l'entité Demande d'Avance.
    
    Colonnes métier: ref_salarie, montant_demande, montant_paye, date_paiement, ref_paiement
    Note: cette table est enrichie avec des données de paiement (LEFT JOIN)
    """
    
    def __init__(self):
        # Initialiser avec les spécificités de l'entité Demande d'Avance
        super().__init__(
            entity_name="demande_avance",
            pk_col="ref_demande_avance",
            business_cols=["ref_salarie", "montant_demande", "montant_paye", "date_paiement", "ref_paiement"]
        )
    
    def fetch_silver(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les données depuis silver.demande_avance enrichie avec paiement (vue DBT).
        
        Returns:
            dict[ref_demande_avance] = {ref_demande_avance, ref_salarie, montant_demande, 
                                        montant_paye, date_paiement, ref_paiement}
            """
        # Requête SQL avec LEFT JOIN pour enrichir les demandes avec les paiements
        sql = """
          select
            d.ref_demande_avance,
            d.ref_salarie,
            d.montant_demande,
            p.montant_paye,
            p.date_paiement,
            p.ref_paiement
          from silver.demande_avance d
          left join silver.paiement p
            on p.ref_demande_avance = d.ref_demande_avance
        """
        with conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()

        # Transformer en dictionnaire indexé par ref_demande_avance
        out = {}
        for rda, ref_salarie, montant_demande, montant_paye, date_paiement, ref_paiement in rows:
            out[str(rda)] = {
                "ref_demande_avance": str(rda),
                "ref_salarie": str(ref_salarie),
                "montant_demande": float(montant_demande) if montant_demande is not None else None,
                "montant_paye": float(montant_paye) if montant_paye is not None else None,
                "date_paiement": date_paiement,  # date or None
                "ref_paiement": str(ref_paiement) if ref_paiement is not None else None,
            }
        return out
    
    def fetch_gold_current(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les versions courantes depuis gold.demande_avance_histo.
        
        Returns:
            dict[ref_demande_avance] = {ref_salarie, montant_demande, montant_paye, 
                                        date_paiement, ref_paiement, record_hash, is_deleted}
            """
        with conn.cursor() as cur:
            cur.execute(
                """
                select
                  ref_demande_avance,
                  ref_salarie,
                  montant_demande,
                  montant_paye,
                  date_paiement,
                  ref_paiement,
                  record_hash,
                  is_deleted
                from gold.demande_avance_histo
                where is_current = true
                """
            )
            rows = cur.fetchall()

        # Transformer en dictionnaire indexé par ref_demande_avance
        out = {}
        for (rda, ref_salarie, montant_demande, montant_paye, date_paiement, 
             ref_paiement, record_hash, is_deleted) in rows:
            out[str(rda)] = {
                "ref_demande_avance": str(rda),  # Inclure la PK pour tombstone
                "ref_salarie": ref_salarie,
                "montant_demande": montant_demande,
                "montant_paye": montant_paye,
                "date_paiement": date_paiement,
                "ref_paiement": ref_paiement,
                "record_hash": record_hash,
                "is_deleted": bool(is_deleted),
            }
        return out
    
    def build_insert_values(self, row: Dict[str, Any], as_of_date: dt.date, 
                          batch_id: int, is_deleted: bool) -> tuple:
        """
        Construit le tuple de valeurs pour l'INSERT dans gold.demande_avance_histo.
        """
        # Calculer le hash de la version (inclut is_deleted)
        record_hash = md5_hash([
            row["ref_salarie"],
            row["montant_demande"],
            row.get("montant_paye"),
            row.get("date_paiement"),
            row.get("ref_paiement"),
            is_deleted,
        ])
        
        # Retourner les valeurs dans l'ordre de la requête INSERT
        return (
            row["ref_demande_avance"],
            row["ref_salarie"],
            row["montant_demande"],
            row.get("montant_paye"),
            row.get("date_paiement"),
            row.get("ref_paiement"),
            as_of_date,           # valid_from
            is_deleted,           # is_deleted
            record_hash,          # record_hash
            batch_id,             # batch_id
        )
    
    def get_insert_sql(self) -> str:
        """
        Retourne la requête SQL d'insertion dans gold.demande_avance_histo.
        """
        return f"""
            insert into {self.table_gold} (
              ref_demande_avance,
              ref_salarie,
              montant_demande,
              montant_paye,
              date_paiement,
              ref_paiement,
              valid_from,
              valid_to,
              is_current,
              is_deleted,
              record_hash,
              batch_id
            )
            values (%s,%s,%s,%s,%s,%s, %s, date '{MAX_DATE_SCD2}', true, %s, %s, %s)
        """


# ============================================================
# POINT D'ENTRÉE PRINCIPAL
# ============================================================

def main():
    """
    Point d'entrée pour l'exécution du script en ligne de commande.
    
    Parse les arguments et déclenche le traitement SCD2 pour demande_avance.
    """
    # Parser les arguments de ligne de commande
    ap = argparse.ArgumentParser(
        description="Apply SCD2 historization for gold.demande_avance_histo from silver.demande_avance (+ paiement)"
    )
    ap.add_argument(
        "--as-of", 
        required=True, 
        help="Date logique du flux (format: YYYY-MM-DD), ex: 2024-08-25"
    )
    ap.add_argument(
        "--batch-dataset", 
        default="demande_avance", 
        help="Nom du dataset dans etl.batch_run (default: demande_avance)"
    )
    args = ap.parse_args()

    # Créer le gestionnaire SCD2 pour demande_avance
    handler = DemandeAvanceSCD2Handler()
    
    # Exécuter le traitement
    handler.run(as_of=args.as_of, batch_dataset=args.batch_dataset)


if __name__ == "__main__":
    main()
