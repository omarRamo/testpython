"""
load_silver.py
--------------
Ingestion des fichiers ERP vers silver_raw.* (tables physiques).

- Supporte Excel (.xlsx) et CSV
- Applique une normalisation légère (types/dates)
- Garantit l'idempotence via etl.batch_run (checksum fichier)

Entrées:
- --dataset : salarie | demande_avance | paiement
- --as-of   : date logique du flux (ex: 2024-08-25)
- --file    : chemin du fichier

Sortie:
- Upsert dans silver_raw.<dataset>
- Synchronisation "snapshot" : suppression des lignes absentes du fichier (gestion suppressions)
- 1 ligne dans etl.batch_run (SUCCESS/FAILED)

Ce script suppose que le fichier fourni est un SNAPSHOT complet du dataset à la date donnée.
Si l’ERP envoie des fichiers incrémentaux (delta), il ne faut PAS activer la suppression.
"""
import argparse
import os
import pandas as pd

from psycopg2.extras import execute_values

from scripts.common import (
    get_conn,
    sha256_file,
    register_batch,
    finish_batch,
    upsert_table,
)

# ------------------------------------------------------------
# CONFIGURATION DES DATASETS
# ------------------------------------------------------------
# Mapping dataset -> table cible + colonnes attendues dans le fichier
# (aligné avec les fichiers Excel fournis)
#
# Cette configuration définit:
# - table: nom complet de la table cible dans silver_raw
# - pk: nom de la colonne de clé primaire (pour les upserts)
# - cols: liste des colonnes attendues dans le fichier source
# ------------------------------------------------------------
DATASETS = {
    "salarie": {
        "table": "silver_raw.salarie",
        "pk": "ref_salarie",
        # salaries.xlsx contient rib en plus des colonnes de base
        "cols": ["ref_salarie", "nni", "nom", "prenom", "rib"],
    },
    "demande_avance": {
        "table": "silver_raw.demande_avance",
        "pk": "ref_demande_avance",
        # demandes_avance.xlsx contient rang_creance + date_reception
        "cols": ["ref_demande_avance", "ref_salarie", "rang_creance", "montant_demande", "date_reception"],
    },
    "paiement": {
        "table": "silver_raw.paiement",
        "pk": "ref_paiement",
        # paiements.xlsx
        "cols": ["ref_paiement", "ref_salarie", "montant_paye", "rib_salarie", "date_paiement", "ref_demande_avance"],
    },
}


# ============================================================
# FONCTIONS UTILITAIRES
# ============================================================


def read_file(path: str) -> pd.DataFrame:
    """
    Lit un fichier CSV ou Excel et retourne un DataFrame pandas.
    
    Args:
        path: Chemin vers le fichier source
        
    Returns:
        pd.DataFrame: Données du fichier
        
    Raises:
        ValueError: Si l'extension du fichier n'est pas supportée
        
    Note:
        - CSV: pd.read_csv (détection automatique du séparateur)
        - Excel: pd.read_excel (1ère feuille par défaut)
    """
    ext = os.path.splitext(path.lower())[1]
    logger.info(f"Reading file: {path} (extension: {ext})")
    
    if ext in [".xlsx", ".xls"]:
        df = pd.read_excel(path)  # Lit la 1ère feuille par défaut
        logger.info(f"Excel file loaded: {len(df)} rows, {len(df.columns)} columns")
        return df
    
    if ext == ".csv":
        df = pd.read_csv(path)
        logger.info(f"CSV file loaded: {len(df)} rows, {len(df.columns)} columns")
        return df
    
    error_msg = f"Unsupported file extension: {ext}. Use .csv, .xlsx, or .xls"
    logger.error(error_msg)
    raise ValueError(error_msg)


def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Applique une normalisation de base au DataFrame.
    
    Args:
        df: DataFrame pandas à normaliser
        
    Returns:
        pd.DataFrame: DataFrame normalisé
        
    Transformations appliquées:
    - Strip des espaces dans les noms de colonnes
    - Remplacement des NaN pandas par None (pour compatibilité SQL)
    """
    # Nettoyer les noms de colonnes (enlever espaces)
    df.columns = [c.strip() for c in df.columns]
    logger.debug(f"Columns after normalization: {list(df.columns)}")
    
    # Remplacer les NaN pandas par None (NULL SQL)
    df = df.where(pd.notnull(df), None)
    
    return df


def sync_deletions_snapshot(conn, table: str, pk: str, pk_values: list[str]) -> int:
    """
    Gestion des suppressions en mode SNAPSHOT.
    
    Principe:
    - Supprime de la table cible toutes les lignes dont la PK n'est pas dans pk_values
    - Si pk_values est vide => table vidée (snapshot vide)
    
    Args:
        conn: Connexion PostgreSQL
        table: Nom de la table (ex: 'silver_raw.salarie')
        pk: Nom de la colonne de clé primaire
        pk_values: Liste des valeurs de PK présentes dans le fichier
        
    Returns:
        int: Nombre de lignes supprimées
        
    Implémentation:
    - Crée une table temporaire avec les PK du fichier
    - Supprime dans la table cible les lignes dont la PK n'existe pas dans la table temp
    """
    with conn.cursor() as cur:
        # Cas particulier: fichier vide => suppression totale
        if not pk_values:
            logger.warning(f"Empty snapshot file => deleting all rows from {table}")
            cur.execute(f"delete from {table};")
            deleted_count = cur.rowcount
            logger.info(f"Deleted all {deleted_count} rows from {table}")
            return deleted_count

        # Créer une table temporaire pour stocker les clés du snapshot
        cur.execute("create temporary table tmp_keys(pk text) on commit drop;")
        logger.debug(f"Created temporary table tmp_keys with {len(pk_values)} keys")

        # Insérer les PKs du fichier dans la table temporaire
        values = [(v,) for v in pk_values]
        execute_values(cur, "insert into tmp_keys(pk) values %s", values, page_size=1000)

        # Supprimer les lignes absentes du snapshot (synchronisation)
        cur.execute(
            f"""
            delete from {table} t
            where not exists (
              select 1 from tmp_keys k where k.pk = t.{pk}
            );
            """
        )
        deleted_count = cur.rowcount
        logger.info(f"Snapshot sync: deleted {deleted_count} rows from {table}")
    """
    Point d'entrée principal du script d'ingestion Silver.
    
    Processus:
    1. Parser les arguments de ligne de commande
    2. Calculer le checksum du fichier (idempotence)
    3. Enregistrer le batch dans etl.batch_run
    4. Lire et normaliser le fichier
    5. Valider les colonnes requises
    6. Upserter les données dans silver_raw
    7. Synchroniser les suppressions (mode snapshot)
    8. Clôturer le batch avec statut SUCCESS/FAILED
    """
    # ========== 1. PARSING DES ARGUMENTS ==========
    ap = argparse.ArgumentParser(
        description="Load ERP files into silver_raw tables with idempotence + snapshot deletions."
    )
    ap.add_argument(
        "--dataset", 
        required=True, 
        choices=DATASETS.keys(),
        help="Dataset to load: salarie | demande_avance | paiement"
    )
    ap.add_argument(
        "--as-of", 
        required=True, 
        help="Date logique du flux (YYYY-MM-DD), ex: 2024-08-25"
    )
    ap.add_argument(
        "--file", 
        required=True, 
        help="Chemin vers le fichier source (.xlsx/.csv)"
    )
    ap.add_argument(
        "--source", 
        default="erp", 
        help="Nom de la source (défaut: erp)"
    )
    ap.add_argument(
        "--snapshot",
        action="store_true",
        default=True,
        help="Mode snapshot (par défaut activé) : supprime les lignes absentes du fichier."
    )
    args = ap.parse_args()

    # Récupérer la configuration du dataset
    meta = DATASETS[args.dataset]
    logger.info(f"Starting ingestion: dataset={args.dataset}, as_of={args.as_of}, file={args.file}")

    # ========== 2. CALCUL DU CHECKSUM (IDEMPOTENCE) ==========
    logger.info("Calculating file checksum...")
    checksum = sha256_file(args.file)
    logger.info(f"File checksum: {checksum}")

    # ========== 3. CONNEXION ET ENREGISTREMENT BATCH ==========
    conn = get_conn()
    try:
        # Enregistrer le batch (vérifie l'idempotence)
        batch_id = register_batch(conn, args.dataset, args.as_of, args.source, checksum)
        
        if batch_id == -1:
            # Flux déjà traité => skip (idempotent)
            logger.info("SKIP: flux déjà traité (idempotent).")
            print("SKIP: flux déjà traité (idempotent).")
            return

        # ========== 4. LECTURE ET NORMALISATION DU FICHIER ==========
        logger.info("Reading and normalizing file...")
        df = read_file(args.file)
        df = normalize_dataframe(df)

        # ========== 5. VALIDATION DES COLONNES ==========
        logger.info("Validating required columns...")
        missing = [c for c in meta["cols"] if c not in df.columns]
        if missing:
            error_msg = (
                f"Missing columns in file for dataset '{args.dataset}': {missing}. "
                f"Columns found: {list(df.columns)}"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        logger.info("All required columns present")

        # ========== 6. SÉLECTION ET CONVERSION DES DONNÉES ==========
        # Sélectionner uniquement les colonnes définies dans la config
        df = df[meta["cols"]].copy()

        # Convertir les colonnes de dates si présentes
        for date_col in ["date_reception", "date_paiement"]:
            if date_col in df.columns:
                logger.debug(f"Converting column {date_col} to date")
                df[date_col] = pd.to_datetime(df[date_col], errors="coerce").dt.date

        # Nettoyage de la clé primaire (important pour les comparaisons)
        pk_col = meta["pk"]
        df[pk_col] = df[pk_col].astype(str).str.strip()
        logger.info(f"Prepared {len(df)} rows for upsert")

        # Conversion en liste de dictionnaires pour l'upsert
        rows = df.to_dict(orient="records")

        # ========== 7. UPSERT VERS SILVER_RAW ==========
        logger.info(f"Upserting {len(rows)} rows into {meta['table']}...")
        upsert_table(conn, meta["table"], meta["pk"], rows, meta["cols"])

        # ========== 8. GESTION DES SUPPRESSIONS (MODE SNAPSHOT) ==========
        deleted = 0
        if args.snapshot:
            logger.info("Running snapshot synchronization (deletions)...")
            pk_values = df[pk_col].dropna().astype(str).tolist()
            deleted = sync_deletions_snapshot(conn, meta["table"], meta["pk"], pk_values)

        # Valider la transaction
        conn.commit()
        logger.info("Transaction committed successfully")

        # ========== 9. CLÔTURE DU BATCH ==========
        msg = f"Ingestion {args.dataset} OK ({len(rows)} rows)"
        if args.snapshot:
            msg += f" + snapshot deletions ({deleted} deleted)"
        finish_batch(conn, batch_id, "SUCCESS", msg)

        # Afficher le résultat pour l'utilisateur
        success_msg = (
            f"OK: batch_id={batch_id} dataset={args.dataset} as_of={args.as_of} "
            f"rows={len(rows)} deleted={deleted}"
        )
        logger.info(success_msg)
        print(success_msg)

    except Exception as e:
        # En cas d'erreur, rollback de la transaction
        logger.error(f"Error during ingestion: {e}", exc_info=True)
        conn.rollback()
        
        # Tenter de marquer le batch comme FAILED
        try:
            if "batch_id" in locals() and batch_id > 0:
                finish_batch(conn, batch_id, "FAILED", str(e))
                logger.info(f"Batch {batch_id} marked as FAILED")
        except Exception as inner_e:
            logger.error(f"Failed to mark batch as FAILED: {inner_e}")
        
        # Re-lever l'exception pour que le script échoue
        raise
    
    finally:
        # Fermer proprement la connexion
        conn.close()
        logger.info("Database connection closed"
        # 5) sélection et conversion minimale
        df = df[meta["cols"]].copy()

        # Convertir dates si présentes
        for date_col in ["date_reception", "date_paiement"]:
            if date_col in df.columns:
                df[date_col] = pd.to_datetime(df[date_col], errors="coerce").dt.date

        # Nettoyage PK (important)
        pk_col = meta["pk"]
        df[pk_col] = df[pk_col].astype(str).str.strip()

        rows = df.to_dict(orient="records")

        # 6) upsert vers silver_raw
        upsert_table(conn, meta["table"], meta["pk"], rows, meta["cols"])

        # 6bis) gestion des suppressions (snapshot sync)
        deleted = 0
        if args.snapshot:
            pk_values = df[pk_col].dropna().astype(str).tolist()
            deleted = sync_deletions_snapshot(conn, meta["table"], meta["pk"], pk_values)

        conn.commit()

        # 7) clôture batch
        msg = f"Ingestion {args.dataset} OK ({len(rows)} rows)"
        if args.snapshot:
            msg += f" + snapshot deletions ({deleted} deleted)"
        finish_batch(conn, batch_id, "SUCCESS", msg)

        print(f"OK: batch_id={batch_id} dataset={args.dataset} as_of={args.as_of} rows={len(rows)} deleted={deleted}")

    except Exception as e:
        conn.rollback()
        try:
            if "batch_id" in locals() and batch_id > 0:
                finish_batch(conn, batch_id, "FAILED", str(e))
        except Exception:
            pass
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    main()
