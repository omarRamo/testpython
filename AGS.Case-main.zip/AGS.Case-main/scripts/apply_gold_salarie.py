"""
Gold SCD2 - salarie
-------------------
Alimente la table gold.salarie_histo en SCD Type 2.

Principe:
- 1 version "courante" (is_current=true) + période de validité (valid_from/valid_to)
- Détection des changements métier via record_hash
- Si changement: close version courante + insert nouvelle version
- Si suppression (absent du flux): close + insert version is_deleted=true

Traçabilité:
- batch_id = lien vers etl.batch_run (quel flux a produit la version)
"""
import argparse
import datetime as dt
from typing import Dict, Any

from scripts.scd2_base import SCD2Handler
from scripts.common import md5_hash, MAX_DATE_SCD2


# ============================================================
# CLASSE SPÉCIALISÉE POUR SALARIÉ
# ============================================================

class SalarieSCD2Handler(SCD2Handler):
    """
    Gestionnaire SCD2 spécifique pour l'entité Salarié.
    
    Colonnes métier: ref_salarie, nni, nom, prenom
    """
    
    def __init__(self):
        # Initialiser avec les spécificités de l'entité Salarié
        super().__init__(
            entity_name="salarie",
            pk_col="ref_salarie",
            business_cols=["nni", "nom", "prenom"]
        )
    
    def fetch_silver(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les données depuis silver.salarie (vue DBT).
        
        Returns:
            dict[ref_salarie] = {ref_salarie, nni, nom, prenom}
        """
        with conn.cursor() as cur:
            cur.execute(
                """
                select ref_salarie, nni, nom, prenom
                from silver.salarie
                """
            )
            rows = cur.fetchall()

        # Transformer en dictionnaire indexé par ref_salarie
        out = {}
        for ref_salarie, nni, nom, prenom in rows:
            out[str(ref_salarie)] = {
                "ref_salarie": str(ref_salarie),
                "nni": str(nni),
                "nom": str(nom),
                "prenom": str(prenom),
            }
        return out
    
    def fetch_gold_current(self, conn) -> Dict[str, Dict[str, Any]]:
        """
        Récupère les versions courantes depuis gold.salarie_histo.
        
        Returns:
            dict[ref_salarie] = {nni, nom, prenom, record_hash, is_deleted}
        """
        with conn.cursor() as cur:
            cur.execute(
                """
                select ref_salarie, nni, nom, prenom, record_hash, is_deleted
                from gold.salarie_histo
                where is_current = true
                """
            )
            rows = cur.fetchall()

        # Transformer en dictionnaire indexé par ref_salarie
        out = {}
        for ref_salarie, nni, nom, prenom, record_hash, is_deleted in rows:
            out[str(ref_salarie)] = {
                "ref_salarie": str(ref_salarie),  # Inclure la PK pour tombstone
                "nni": nni,
                "nom": nom,
                "prenom": prenom,
                "record_hash": record_hash,
                "is_deleted": bool(is_deleted),
            }
        return out
    
    def build_insert_values(self, row: Dict[str, Any], as_of_date: dt.date, 
                          batch_id: int, is_deleted: bool) -> tuple:
        """
        Construit le tuple de valeurs pour l'INSERT dans gold.salarie_histo.
        """
        # Calculer le hash de la version (inclut is_deleted)
        record_hash = md5_hash([row["nni"], row["nom"], row["prenom"], is_deleted])
        
        # Retourner les valeurs dans l'ordre de la requête INSERT
        return (
            row["ref_salarie"],
            row["nni"],
            row["nom"],
            row["prenom"],
            as_of_date,           # valid_from
            is_deleted,           # is_deleted
            record_hash,          # record_hash
            batch_id,             # batch_id
        )
    
    def get_insert_sql(self) -> str:
        """
        Retourne la requête SQL d'insertion dans gold.salarie_histo.
        """
        return f"""
            insert into {self.table_gold} (
              ref_salarie, nni, nom, prenom,
              valid_from, valid_to, is_current, is_deleted,
              record_hash, batch_id
            )
            values (%s,%s,%s,%s, %s, date '{MAX_DATE_SCD2}', true, %s, %s, %s)
        """



# ============================================================
# POINT D'ENTRÉE PRINCIPAL
# ============================================================

def main():
    """
    Point d'entrée pour l'exécution du script en ligne de commande.
    
    Parse les arguments et déclenche le traitement SCD2 pour salarie.
    """
    # Parser les arguments de ligne de commande
    ap = argparse.ArgumentParser(
        description="Apply SCD2 historization for gold.salarie_histo from silver.salarie"
    )
    ap.add_argument(
        "--as-of", 
        required=True, 
        help="Date logique du flux (format: YYYY-MM-DD), ex: 2024-08-25"
    )
    ap.add_argument(
        "--batch-dataset",
        default="salarie",
        help="Nom du dataset dans etl.batch_run (default: salarie)",
    )
    args = ap.parse_args()

    # Créer le gestionnaire SCD2 pour salarié
    handler = SalarieSCD2Handler()
    
    # Exécuter le traitement
    handler.run(as_of=args.as_of, batch_dataset=args.batch_dataset)


if __name__ == "__main__":
    main()
