"""
common.py
---------
Fonctions utilitaires partagées par les scripts Python.

Ce module porte 3 responsabilités :
1) Connexion PostgreSQL (via variables d'environnement)
2) Idempotence : calcul du checksum et enregistrement dans etl.batch_run
3) Upsert générique dans les tables silver_raw.*

Pourquoi etl.batch_run ?
- Garantir la rejouabilité (re-run) sans doublons
- Tracer l'origine technique de chaque chargement (batch_id)
"""
import os
import hashlib
import logging
from pathlib import Path
from contextlib import contextmanager

import psycopg2
from dotenv import load_dotenv
from psycopg2.extras import execute_values

# ============================================================
# CONSTANTES
# ============================================================
CHUNK_SIZE = 1024 * 1024  # 1 MB pour lecture fichiers
MAX_DATE_SCD2 = '9999-12-31'  # Date de fin par défaut pour SCD2

# ============================================================
# CONFIGURATION DU LOGGING
# ============================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================
# CHEMINS ET ENVIRONNEMENT
# ============================================================
# Charge .env depuis la racine du projet (ags_case/.env)
PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_PATH = PROJECT_ROOT / ".env"
load_dotenv(dotenv_path=ENV_PATH)

# ============================================================
# GESTION DES CONNEXIONS POSTGRESQL
# ============================================================

def get_conn():
    """
    Établit une connexion PostgreSQL en utilisant les variables d'environnement.
    
    Returns:
        psycopg2.connection: Connexion à la base de données
        
    Raises:
        RuntimeError: Si des variables d'environnement sont manquantes
        psycopg2.Error: Si la connexion échoue
    """
    # Récupération des paramètres de connexion depuis .env
    host = os.getenv("PGHOST")
    port = os.getenv("PGPORT")
    dbname = os.getenv("PGDATABASE")
    user = os.getenv("PGUSER")
    password = os.getenv("PGPASSWORD")

    # Vérification que toutes les variables sont définies
    missing = [k for k, v in {
        "PGHOST": host,
        "PGPORT": port,
        "PGDATABASE": dbname,
        "PGUSER": user,
        "PGPASSWORD": password,
    }.items() if not v]
    if missing:
        error_msg = f"Missing env vars: {missing}. Check {ENV_PATH}"
        logger.error(error_msg)
        raise RuntimeError(error_msg)

    # Connexion à la base de données
    try:
        conn = psycopg2.connect(
            host=host,
            port=int(port),
            dbname=dbname,
            user=user,
            password=password,
        )
        logger.info(f"Connected to database {dbname}@{host}:{port}")
        return conn
    except psycopg2.Error as e:
        logger.error(f"Failed to connect to database: {e}")
        raise


@contextmanager
def get_db_connection():
    """
    Context manager pour gérer automatiquement l'ouverture/fermeture de connexion.
    
    Yields:
        psycopg2.connection: Connexion à la base de données
        
    Example:
        with get_db_connection() as conn:
            # Utiliser conn ici
            pass
    """
    conn = get_conn()
    try:
        yield conn
    except Exception as e:
        logger.error(f"Error during database operation: {e}")
        raise
    finally:
        conn.close()
        logger.debug("Database connection closed")


# ============================================================
# UTILITAIRES DE HASHING
# ============================================================

def sha256_file(path: str) -> str:
    """
    Calcule le hash SHA256 d'un fichier pour détecter les changements.
    
    Args:
        path: Chemin vers le fichier
        
    Returns:
        str: Hash SHA256 en hexadécimal
        
    Note:
        Lit le fichier par chunks pour économiser la mémoire sur les gros fichiers
    """
    Enregistre un nouveau batch dans etl.batch_run pour garantir l'idempotence.
    
    Args:
        conn: Connexion PostgreSQL
        dataset: Nom du dataset (salarie, demande_avance, paiement)
        as_of_date: Date logique du flux (format: YYYY-MM-DD)
        source_name: Nom de la source (ex: 'erp')
        checksum: Hash SHA256 du fichier source
        
    Returns:
        int: batch_id du nouveau batch créé, ou -1 si déjà traité (idempotent)
    """
    with conn.cursor() as cur:
        # Vérifier si ce batch existe déjà (idempotence)
        cur.execute(
            """
            select batch_id, status
            from etl.batch_run
            where dataset=%s and as_of_date=%s and source_checksum=%s
            """,
            (dataset, as_of_date, checksum),
        )
        row = cur.fetchone()
        
        # Si le batch existe déjà avec statut SUCCESS ou SKIPPED => skip
        if row:
            batch_id, status = row
            if status in ("SUCCESS", "SKIPPED"):
                logger.info(f"Batch already processed: dataset={dataset}, as_of={as_of_date}, status={status}")
                return -1

        # Créer un nouveau batch avec statut STARTED
        cur.execute(
            """
            insert into etl.batch_run(dataset, as_of_date, source_name, source_checksum, status)
            values (%s, %s, %s, %s, 'STARTED')
            returning batch_id
            """,
            (dataset, as_of_date, source_name, checksum),
        )
        batch_id = cur.fetchone()[0]
        logger.info(f"Batch registered: batch_id={batch_id}, dataset={dataset}, as_of={as_of_date}")se str(v) for v in values)
    return hashlib.md5(s.encode("utf-8")).hexdigest()


# ============================================================
# GESTION DE L'IDEMPOTENCE (etl.batch_run)
# ============================================================
# Principe:
# - Si (dataset, as_of_date, checksum) existe déjà en SUCCESS => SKIP
# - Sinon => créer un batch STARTED puis le clôturer en SUCCESS/FAILED

def register_batch(conn, dataset: str, as_of_date: str, source_name: str, checksum: str) -> int:
    """
    Enregistre un nouveau batch dans etl.batch_run pour garantir l'idempotence.
    
    Args:
        conn: Connexion PostgreSQL
        dataset: Nom du dataset (salarie, demande_avance, paiement)
        as_of_date: Date logique du flux (format: YYYY-MM-DD)
        source_name: Nom de la source (ex: 'erp')
        checksum: Hash SHA256 du fichier source
        
    Returns:
        int: batch_id du nouveau batch créé, ou -1 si déjà traité (idempotent)
    """
    with conn.cursor() as cur:
        cur.execute(
            """
            select batch_id, status
            from etl.batch_run
            where dataset=%s and as_of_date=%s and source_checksum=%s
            """,
            (dataset, as_of_date, checksum),
        )
        row = cur.fetchone()
    """
    Clôture un batch en mettant à jour son statut final.
    
    Args:
        conn: Connexion PostgreSQL
        batch_id: ID du batch à clôturer
        status: Statut final ('SUCCESS' ou 'FAILED')
        message: Message optionnel décrivant le résultat
    """
    with conn.cursor() as cur:
        # Mettre à jour le batch avec le statut final et l'heure de fin
        cur.execute(
            """
            update etl.batch_run
            set finished_at=now(), status=%s, message=%s
            where batch_id=%s
            """,
            (status, message, batch_id),
        )
    conn.commit()
    logger.info(f"Batch finished: batch_id={batch_id}, status={status}")


def get_latest_batch_id(conn, dataset: str, as_of_date: str) -> int:
    """
    Récupère le dernier batch SUCCESS pour un dataset et une date donnés.
    
    Args:
        conn: Connexion PostgreSQL
        dataset: Nom du dataset (salarie, demande_avance, paiement)
        as_of_date: Date logique du flux (format: YYYY-MM-DD)
        
    Returns:
        int: batch_id du dernier batch SUCCESS
        
    Raises:
    """
    Insère ou met à jour des lignes dans une table silver_raw.
    
    Args:
        conn: Connexion PostgreSQL
        table: Nom de la table (ex: 'silver_raw.salarie')
        pk_col: Nom de la colonne de clé primaire
        rows: Liste de dictionnaires contenant les données
        cols: Liste des colonnes à insérer/mettre à jour
    """
    # Si aucune ligne à insérer, sortir immédiatement
    if not rows:
        logger.debug(f"No rows to upsert in {table}")
        return

    # Préparer les valeurs pour l'insert
    values = [[r.get(c) for c in cols] for r in rows]
    col_list = ", ".join(cols)
    # Clause SET pour l'update (exclut la clé primaire)
    set_clause = ", ".join([f"{c}=excluded.{c}" for c in cols if c != pk_col])

    # Construction de la requête UPSERT (INSERT ... ON CONFLICT DO UPDATE)
    sql = f"""
        insert into {table} ({col_list})
        values %s
        on conflict ({pk_col})
        do update set {set_clause}
    """
    
    with conn.cursor() as cur:
        # Utilise execute_values pour un insert batch performant
        execute_values(cur, sql, values)
    
    conn.commit()
    logger.info(f"Upserted {len(rows)} rows into {table}"r.fetchone()
        if not row:
            error_msg = f"No SUCCESS batch found for dataset={dataset} as_of_date={as_of_date}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        batch_id = int(row[0])
        logger.debug(f"Found batch_id={batch_id} for dataset={dataset}, as_of={as_of_date}")
        return batch_id


# ============================================================
# UPSERT DANS SILVER_RAW
# ============================================================
# Principe:
# - silver_raw est la "landing zone" structurée
# - on met à jour les enregistrements si la clé métier existe déjà
# - cela permet de simuler les corrections ERP sur les flux suivants

def upsert_table(conn, table: str, pk_col: str, rows: list[dict], cols: list[str]):
    """
    Insère ou met à jour des lignes dans une table silver_raw.
    
    Args:
        conn: Connexion PostgreSQL
        table: Nom de la table (ex: 'silver_raw.salarie')
        pk_col: Nom de la colonne de clé primaire
        rows: Liste de dictionnaires contenant les données
        cols: Liste des colonnes à insérer/mettre à jour
    """

def finish_batch(conn, batch_id: int, status: str, message: str = ""):
    with conn.cursor() as cur:
        cur.execute(
            """
            update etl.batch_run
            set finished_at=now(), status=%s, message=%s
            where batch_id=%s
            """,
            (status, message, batch_id),
        )
    conn.commit()

# Upsert silver_raw :
# - on considère silver_raw comme la "landing zone" structurée
# - on met à jour les enregistrements si la clé métier existe déjà
# - cela permet de simuler les corrections ERP sur les flux suivants

def upsert_table(conn, table: str, pk_col: str, rows: list[dict], cols: list[str]):
    if not rows:
        return

    values = [[r.get(c) for c in cols] for r in rows]
    col_list = ", ".join(cols)
    set_clause = ", ".join([f"{c}=excluded.{c}" for c in cols if c != pk_col])

    sql = f"""
        insert into {table} ({col_list})
        values %s
        on conflict ({pk_col})
        do update set {set_clause}
    """
    with conn.cursor() as cur:
        execute_values(cur, sql, values)
    conn.commit()
